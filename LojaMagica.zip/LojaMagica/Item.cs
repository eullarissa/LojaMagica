using System;

namespace LojaMagica
{
  public class Item
  {
    public string Nome;
    public string Descricao;
    public string Categoria;
    public int Moedas;

    public Item(string nome, string descricao, string categoria, int moedas)
    {
      this.Nome = nome;
      this.Descricao = descricao;
      this.Categoria = categoria;
      this.Moedas = moedas;
    }

    public void ImprimirItem()
    {
      Console.WriteLine("Nome:\t\t{0}", this.Nome);
      Console.WriteLine("Descrição:\t{0}", this.Descricao);
      Console.WriteLine("Categoria:\t{0}", this.Categoria);
      Console.WriteLine("Moedas:\t\t{0}", this.Moedas);
      Console.WriteLine("----------------------------");


    }

  }
}