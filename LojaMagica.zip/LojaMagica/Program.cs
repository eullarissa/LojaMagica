using System;

namespace LojaMagica
{
  class Program
  {
    static void Main(string[] arg)
    {
      Item varinhas = new Item("Vara da morte", "Vara com sangue", "Varinhas", 30);

      Item pergaminhos = new Item("Pergama letal", "Vai e fica", "Pergaminhos",25);

      Item animais = new Item("Cachorro raivoso", "pincher", "animaisMagicos", 55);


      Item roupas = new Item("Roupa", "roupas criativas", "roupas", 70);

      Item vassoura = new Item("Vassoura voadora",  "Vassoura que voa", "Vassouras", 20);

      Item livro = new Item("LojaMagica", "Sobre a loja", "livros", 15);

      varinhas.ImprimirItem();
      pergaminhos.ImprimirItem();
      animais.ImprimirItem();
      roupas.ImprimirItem();
      vassoura.ImprimirItem();
      livro.ImprimirItem();

    

      Personagem larissa = new Personagem(nome: "Larissa Nascimento");
      Personagem ygor = new Personagem(nome: "Ygor Canalli");

      larissa.ComprarItem(varinhas);
      larissa.ComprarItem(pergaminhos);
      larissa.ComprarItem(roupas);

      ygor.ComprarItem(livro);
      ygor.ComprarItem(animais);
      ygor.ComprarItem(varinhas);

      larissa.ImprimirPersonagem();
      ygor.ImprimirPersonagem();
      
      
    }
  }
}